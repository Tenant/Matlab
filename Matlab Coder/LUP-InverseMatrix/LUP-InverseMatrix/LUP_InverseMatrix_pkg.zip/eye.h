//
// File: eye.h
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 11-Apr-2018 13:35:38
//
#ifndef EYE_H
#define EYE_H

// Include Files
#include <cmath>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "LUP_InverseMatrix_types.h"

// Function Declarations
extern void eye(double varargin_1, emxArray_real_T *I);

#endif

//
// File trailer for eye.h
//
// [EOF]
//
