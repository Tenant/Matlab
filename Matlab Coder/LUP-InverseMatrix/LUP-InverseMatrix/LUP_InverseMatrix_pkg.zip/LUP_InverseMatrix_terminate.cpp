//
// File: LUP_InverseMatrix_terminate.cpp
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 11-Apr-2018 13:35:38
//

// Include Files
#include "rt_nonfinite.h"
#include "LUP_InverseMatrix.h"
#include "LUP_InverseMatrix_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void LUP_InverseMatrix_terminate()
{
  // (no terminate code required)
}

//
// File trailer for LUP_InverseMatrix_terminate.cpp
//
// [EOF]
//
