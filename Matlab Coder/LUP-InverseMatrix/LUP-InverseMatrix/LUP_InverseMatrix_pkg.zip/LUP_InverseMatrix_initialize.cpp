//
// File: LUP_InverseMatrix_initialize.cpp
//
// MATLAB Coder version            : 3.2
// C/C++ source code generated on  : 11-Apr-2018 13:35:38
//

// Include Files
#include "rt_nonfinite.h"
#include "LUP_InverseMatrix.h"
#include "LUP_InverseMatrix_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void LUP_InverseMatrix_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for LUP_InverseMatrix_initialize.cpp
//
// [EOF]
//
